import functions_framework
from google.cloud import storage, bigquery
import pandas as pd
from io import StringIO

def transform(file_data):
    df = pd.read_csv(StringIO(file_data))
    df = df.drop("comment", axis=1)
    df["user_country"] = df["user_country"].str.upper()
        
    transformed_data = df.to_dict(orient='records')

    return transformed_data

# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def gcs_to_bigquery(cloud_event):
    data = cloud_event.data

    bucket_name = data["bucket"]
    file_name = data["name"]
   
    print(f"Bucket: {bucket_name}")
    print(f"File: {file_name}")

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)
    file_data = blob.download_as_text()

    transformed_data = transform(file_data)

    bq_client = bigquery.Client()
    dataset_id = 'da_pipeline3_sink'
    table_id = 'harry_potter_table'
    dataset_ref = bq_client.dataset(dataset_id)
    table_ref = dataset_ref.table(table_id)
    table = bq_client.get_table(table_ref)
    errors = bq_client.insert_rows_json(table, transformed_data)

    if errors:
        print(f'Error inserting rows: {errors}')
    else:
        print('Rows inserted successfully.')
    