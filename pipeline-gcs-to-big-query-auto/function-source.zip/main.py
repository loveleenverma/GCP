import functions_framework
from google.cloud import storage, bigquery
import pandas as pd 
from io import StringIO

def detect_schema(file_data):
    df = pd.read_csv(StringIO(file_data))
    print(df)

    column_name = df.columns
    dtypes = df.dtypes

    print(f"columns: {column_name}")
    print(f"dtypes: {dtypes}")

    schema = []

    for column_name, dtype in zip(column_name, dtypes):
        if dtype == 'int64':
            bq_type = 'INTEGER'
        elif dtype == 'float64':
            bq_type = 'FLOAT'
        else:
            bq_type = 'STRING'
        
        schema.append(bigquery.SchemaField(column_name, bq_type))

    return schema


# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def gcs_to_bigquery(cloud_event):
    data = cloud_event.data

    bucket_name = data["bucket"]
    file_name = data["name"]

    print(f"Bucket: {bucket_name}")
    print(f"File: {file_name}")
   
    storage_client = storage.Client()
    bucket_ref = storage_client.bucket(bucket_name)
    file_ref = bucket_ref.blob(file_name)
    file_data = file_ref.download_as_text()

    print(file_data)

    schema = detect_schema(file_data)

    print(schema)

    big_query_client = bigquery.Client()
    dataset_id = "da_pipeline3_sink"
    table_id = file_name.split('.')[0]

    dataset_ref = big_query_client.dataset(dataset_id)
    table_ref = dataset_ref.table(table_id)

    table = bigquery.Table(table_ref, schema=schema)

    try:
        big_query_client.create_table(table, exists_ok=True)
        print(f"Table {table_id} created or overwritten in dataset {dataset_id}.")

    except Exception as e:
        print(f"Error creating or overwriting table: {e}")

    df = pd.read_csv(StringIO(file_data))
    data = df.to_dict(orient = "records" )
    errors = big_query_client.insert_rows_json(table, data)

    if errors:
        print(f'Error inserting rows: {errors}')
    else:
        print('Rows inserted successfully.')





    
